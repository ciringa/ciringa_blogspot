

function goto(al){

  window.open(al);

}


function sorry(){

	alert("sorry bro there's no link or maybe the site is closed")
}